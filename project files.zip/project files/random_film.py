import pandas as pd


def random_film(film_list): #film_list is a dataframe
    a_film = film_list.sample(n=1)
    film_title = (a_film.loc[:,'标题']).to_string(index=False, header=False)
    detail_link = a_film.loc[:,'详情链接'].to_string(index=False, header=False)
    pic_link = a_film.loc[:,'图片链接'].to_string(index=False, header=False)
    year = a_film.loc[:,'年份'].to_string(index=False, header=False)
    country = a_film.loc[:,'地区'].to_string(index=False, header=False)
    info = a_film.loc[:,'信息'].to_string(index=False, header=False)
    director = info.split('主演')[0].strip()[4:]
    actor = info.split('主演: ')[1].strip()
    if '\\' in actor:
        actor = acotr.split('/')[0]
    genere = a_film.loc[:,'类型'].to_string(index=False, header=False)
    score = a_film.loc[:,'评分'].to_string(index=False, header=False)
    people_watched = a_film.loc[:,'评价人数'].to_string(index=False, header=False)
    brief_intro = a_film.loc[:,'简介'].to_string(index=False, header=False)
    #返回搜索的视频平台超链接
    #tencentvideo_link = 'https://v.qq.com/x/search/?q='+ film_title
    #iqiyi_link = 'https://www.iq.com/search?query=' + film_title + '% &originInput=' + film_title
    #youku_link = 'https://so.youku.com/search_video/q_' + film_title + '?searchfrom=1'
    return film_title,detail_link,pic_link,year,country,info,genere,score,people_watched,brief_intro, director,actor

def random_book(book_list): #book_list is a dataframe
    a_book = book_list.sample(n=1)
    book_title = (a_book.loc[:,'标题']).to_string(index=False, header=False)
    detail_link = a_book.loc[:,'详情链接'].to_string(index=False, header=False)
    pic_link = a_book.loc[:,'图片链接'].to_string(index=False, header=False)
    author = a_book.loc[:,'作者'].to_string(index=False, header=False)
    publisher = a_book.loc[:,'出版社'].to_string(index=False, header=False)
    time = a_book.loc[:,'出版时间'].to_string(index=False, header=False)
    price = a_book.loc[:,'价格'].to_string(index=False, header=False)
    score = a_book.loc[:,'评分'].to_string(index=False, header=False)
    people_rated = a_book.loc[:,'评价人数'].to_string(index=False, header=False)
    brief_intro = a_book.loc[:,'简介'].to_string(index=False, header=False)
    return book_title,detail_link,pic_link,author,publisher,time,price,score,people_rated,brief_intro

def random_music(music_list): #music_list is a dataframe
    a_music = music_list.sample(n=1)
    music_title = (a_music.loc[:,'标题']).to_string(index=False, header=False)
    detail_link = a_music.loc[:,'详情链接'].to_string(index=False, header=False)
    pic_link = a_music.loc[:,'图片链接'].to_string(index=False, header=False)
    singer = a_music.loc[:,'歌手'].to_string(index=False, header=False)
    time = a_music.loc[:,'发行时间'].to_string(index=False, header=False)
    genere = a_music.loc[:,'类型'].to_string(index=False, header=False)
    medium = a_music.loc[:,'介质'].to_string(index=False, header=False)
    music_type = a_music.loc[:,'流派'].to_string(index=False, header=False)
    score = a_music.loc[:,'评分'].to_string(index=False, header=False)
    people_rated = a_music.loc[:,'评价人数'].to_string(index=False, header=False)
    return music_title,detail_link,pic_link,singer,time,genere,medium,music_type,score, people_rated

if __name__ == '__main__':
    #Test
    #random film
    film_title,detail_link,pic_link,year,country,\
    info,genere,score,people_watched,brief_intro,director,actor\
    = random_film(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣电影top250最终版.xlsx'))
    print(f'{film_title}\n{detail_link}\n{director}\n{actor}')
    #random book
    a,b,c,d,e,f,g,h,i,j = random_book(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣图书top250最终版.xlsx'))
    print(f'{a}\n{b}\n{c}\n{i}')
    #random music
    a,b,c,d,e,f,g,h,i,j = random_music(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣音乐top250最终版.xlsx'))
    print(f'{a}\n{b}\n{c}\n{i}')

    #类型数数
    film_type = pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣电影top250最终版.xlsx').loc[:,'类型']
    type_list = []
    for i in range(film_type.shape[0]):
        the_types = film_type.loc[i:].to_string(index=False, header=False).split()
        for j in range(len(the_types)):
            type_list.append(the_types[j])
    print(set(type_list))