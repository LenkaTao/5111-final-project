from flask import Flask, url_for, redirect, render_template, request
from random_film import random_film, random_book, random_music
import pandas as pd

app = Flask(__name__)

@app.route('/randomfilm') #点击random film
def randomfilm():
    film_title,detail_link,pic_link,year,country,\
    info,genere,score,people_watched,brief_intro = random_film(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣电影top250最终版.xlsx'))
    return render_template('randomfilm.html',\
                           film_title = film_title,detail_link = detail_link,pic_link = pic_link, year = year,\
                           country = country, info = info, genere = genere, score = score,\
                           people_watched = people_watched, brief_intro = brief_intro
                            )

@app.route('/randombook') #点击random book
def randombook():
    book_title,detail_link,pic_link,author,publisher,\
    time,price,score,people_rated,brief_intro = random_book(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣图书top250最终版.xlsx'))
    return render_template('randombook.html',\
                           book_title = book_title,detail_link = detail_link,pic_link = pic_link,\
                           author = author,publisher = publisher,time = time, price = price,\
                           score = score,people_rated = people_rated,brief_intro = brief_intro
                            )

@app.route('/randommusic') #点击random music
def randommusic():
    music_title,detail_link,pic_link,singer,time,genere,medium,music_type,score, people_rated\
     = random_music(pd.read_excel('豆瓣电影、图书、音乐top250爬虫代码及数据/豆瓣音乐top250最终版.xlsx'))
    return render_template('randommusic.html',\ 
                           music_title = music_title,detail_link = detail_link,pic_link = pic_link,\
                           singer = singer,time = time,genere = genere,medium = medium,\
                           music_type = music_type,score = score, people_rated = people_rated
                            )

@app.route('/') #如果网址只有一个/，会自动跳转到***/home
def index():
    return redirect(url_for('home'))

@app.route('/home') #如果是***/home，就返回home.html,也就是主页
def home():
    return render_template('home.html')

if __name__ == '__main__':
    app.run()